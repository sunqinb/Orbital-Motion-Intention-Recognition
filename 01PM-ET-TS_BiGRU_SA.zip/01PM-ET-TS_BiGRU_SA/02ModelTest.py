#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Apr 18 11:56:52 2023

@author: sunqinbo
"""
## 导入本节所需的模块
import numpy as np
import matplotlib.pyplot as plt
import torch
import torch.utils.data as Data
from sklearn.metrics import accuracy_score     # 准确率
from sklearn.metrics import precision_score    # 精确率
from sklearn.metrics import recall_score       # 召回率
from sklearn.metrics import f1_score           # F1分数
from sklearn.metrics import fbeta_score
from sklearn.metrics import confusion_matrix   # 混淆矩阵
from sklearn.metrics import classification_report# 分类报告
from sklearn.metrics import precision_recall_curve
from sklearn.metrics import average_precision_score
import itertools
import seaborn as sns
from matplotlib import rcParams
# 设置全局字体为 "Nimbus Roman"
rcParams['font.family'] = 'serif'
rcParams['font.serif'] = 'Nimbus Roman'

torch.cuda.empty_cache()
device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
Validate_Data = np.load('./Dataset/validationset /Test_DATA.csv.npy')
Validate_Label = np.load('./Dataset/validationset /Test_DATA_labels.csv.npy')

# 读取模型
MyBiGRUnet = torch.load('./SAVEMODEL/bigru120.pt')

x_validate_t = torch.from_numpy(Validate_Data.astype(np.float32))
y_validate_t = torch.from_numpy(Validate_Label.astype(np.int64))

# 定义一个数据加载器
validate_data = Data.TensorDataset(x_validate_t,y_validate_t)
validate_loader = Data.DataLoader(
        dataset= validate_data, 
        batch_size=3040, 
        # 随机排序
        shuffle=True,
        # 多个线程并行计算
        num_workers= 5
    )

validate_acc_all = []
validate_precision_all = []
validate_recall_all = []
validate_F1_all = []
validate_F2_all = []

torch.cuda.empty_cache()
true_lab_all = np.array([])
pre_lab_all  = np.array([])
probability_all = np.array([])
for step, (b_x, b_y) in enumerate(validate_loader):
    b_x = b_x.to(device)
    output = MyBiGRUnet(b_x)  # 前向计算
    probability = torch.softmax(output,1).cpu()
    pre_lab = torch.argmax(output, 1)  # 1代表行
    pre_lab = pre_lab.cpu()
    
    # 准确率 validate_accuracy
    validate_accuracy = accuracy_score(b_y, pre_lab)
    # 精确率 precision
    validate_precision = precision_score(b_y, pre_lab,average='macro')
    # 召回率 recall
    validate_recall = recall_score(b_y, pre_lab,average='macro')
    # F1 分数
    validate_F1 = f1_score(b_y, pre_lab,average='macro')
    validate_F2 = fbeta_score(b_y, pre_lab,beta=2,average='macro')
    # 数据拼接
    validate_acc_all.append(validate_accuracy)
    validate_precision_all.append(validate_precision)
    validate_recall_all.append(validate_recall)
    validate_F1_all.append(validate_F1)
    validate_F2_all.append(validate_F2)
    
    # 记录结果 标签
    true_lab_numpy = b_y.numpy()  # 真实标签
    true_lab_all = np.append(true_lab_all,true_lab_numpy)
    pre_lab_numpy = pre_lab.numpy()  # 预测标签
    pre_lab_all = np.append(pre_lab_all,pre_lab_numpy)
    probability_numpy = probability.detach().numpy()
    if step ==0:
        probability_all = probability_numpy
    else:
        probability_all = np.vstack([probability_all,probability_numpy])
 
np.save('./SAVEDATA/validate_acc_all.csv',validate_acc_all) 
np.save('./SAVEDATA/validate_precision_all.csv',validate_precision_all) 
np.save('./SAVEDATA/validate_recall_all.csv',validate_recall_all)    
np.save('./SAVEDATA/validate_F1_all.csv',validate_F1_all)    
np.save('./SAVEDATA/validate_F2_all.csv',validate_F2_all)   
 
fig, ax = plt.subplots(2,2,figsize=(15,9))
ax1 = plt.subplot(221)
ax1.set_ylabel('Accuracy',fontdict={'family': 'Times New Roman','size': 12})
ax1.set_xlabel('Serial Number', fontdict={'family': 'Times New Roman','size': 12})
ax1.plot(validate_acc_all, linestyle = "-" , lw = 2, color='darkred', label='Accuracy curve for BiGRU_SA')
ax1.set_xlim([0, 100])
ax1.set_ylim([np.min(validate_acc_all)-0.005, np.max(validate_acc_all)+0.005])
ax1.legend(prop={'family': 'Times New Roman','size': 14},loc='upper right')
ax1.spines['bottom'].set_linewidth(2);###设置底部坐标轴的粗细
ax1.spines['left'].set_linewidth(2);###设置底部坐标轴的粗细
ax1.spines['right'].set_linewidth(2);###设置底部坐标轴的粗细
ax1.spines['top'].set_linewidth(2);###设置底部坐标轴的粗细
plt.grid()
ax2 = plt.subplot(222)
ax2.set_ylabel('Precision',fontdict={'family': 'Times New Roman','size': 12})
ax2.set_xlabel('Serial Number', fontdict={'family': 'Times New Roman','size': 12})
ax2.plot(validate_precision_all, linestyle = "-" , lw = 2, color='blue', label='Precision curve for BiGRU_SA')
ax2.set_xlim([0, 100])
ax2.set_ylim([np.min(validate_precision_all)-0.005, np.max(validate_precision_all)+0.005])
ax2.legend(prop={'family': 'Times New Roman','size': 14},loc='upper right')
ax2.spines['bottom'].set_linewidth(2);###设置底部坐标轴的粗细
ax2.spines['left'].set_linewidth(2);###设置底部坐标轴的粗细
ax2.spines['right'].set_linewidth(2);###设置底部坐标轴的粗细
ax2.spines['top'].set_linewidth(2);###设置底部坐标轴的粗细
plt.grid()
ax3 = plt.subplot(223)
ax3.set_ylabel('Recall',fontdict={'family': 'Times New Roman','size': 12})
ax3.set_xlabel('Serial Number', fontdict={'family': 'Times New Roman','size': 12})
ax3.plot(validate_recall_all, linestyle = "-" , lw = 2, color='red', label='Recall curve for BiGRU_SA')
ax3.set_xlim([0, 100])
ax3.set_ylim([np.min(validate_recall_all)-0.005, np.max(validate_recall_all)+0.005])
ax3.legend(prop={'family': 'Times New Roman','size': 14},loc='upper right')
ax3.spines['bottom'].set_linewidth(2);###设置底部坐标轴的粗细
ax3.spines['left'].set_linewidth(2);###设置底部坐标轴的粗细
ax3.spines['right'].set_linewidth(2);###设置底部坐标轴的粗细
ax3.spines['top'].set_linewidth(2);###设置底部坐标轴的粗细
plt.grid()
ax4 = plt.subplot(224)
ax4.set_ylabel('F1_score',fontdict={'family': 'Times New Roman','size': 12})
ax4.set_xlabel('Serial Number', fontdict={'family': 'Times New Roman','size': 12})
ax4.plot(validate_F1_all, linestyle = "-" , lw = 2, color='green', label='F1_score curve for BiGRU_SA')
ax4.set_xlim([0, 100])
ax4.set_ylim([np.min(validate_F1_all)-0.005, np.max(validate_F1_all)+0.005])
ax4.legend(prop={'family': 'Times New Roman','size': 14},loc='upper right')
ax4.spines['bottom'].set_linewidth(2);###设置底部坐标轴的粗细
ax4.spines['left'].set_linewidth(2);###设置底部坐标轴的粗细
ax4.spines['right'].set_linewidth(2);###设置底部坐标轴的粗细
ax4.spines['top'].set_linewidth(2);###设置底部坐标轴的粗细
plt.grid()
fig.savefig("./SAVEDATA/APRF_BiGRU.png",dpi=1200,bbox_inches = 'tight')


# 准确率 validate_accuracy
validate_accuracy_mean = accuracy_score(true_lab_all, pre_lab_all)
# 精确率 precision
validate_precision_mean = precision_score(true_lab_all, pre_lab_all,average='macro')
# 召回率 recall
validate_recall_mean = recall_score(true_lab_all, pre_lab_all,average='macro')
# F1 分数
validate_F1_mean = f1_score(true_lab_all, pre_lab_all,average='macro')
# F1 分数
validate_F2_all_mean = fbeta_score(true_lab_all, pre_lab_all,beta=2,average='macro')

# 混淆矩阵
CM = confusion_matrix(true_lab_all,pre_lab_all)
M2 = CM
#分类报告输出
CR = classification_report(true_lab_all, pre_lab_all)
M1 = CR


def plot_confusion_matrix(cm, classes, ad ,normalize=False, title='Confusion matrix', cmap=plt.cm.Reds):
    if normalize:
        cm = cm.astype('float') / cm.sum(axis=1)[:, np.newaxis] * 100
        print("Normalized confusion matrix")
    else:
        print('Confusion matrix, without normalization')

    fig1 = plt.figure(figsize=(24, 18))
    # 绘制蓝色背景矩阵
    plt.imshow(cm, interpolation='nearest', cmap=cmap)

    # plt.title(title,fontdict={'family': 'Nimbus Roman','size': 12})
    cbar = plt.colorbar()
    # 设置 colorbar 标签的字体大小为 15
    cbar.ax.tick_params(labelsize=18)

    tick_marks = np.arange(len(classes))
    plt.xticks(tick_marks, classes, rotation=90,fontdict={'family': 'Nimbus Roman','size': 25})
    plt.yticks(tick_marks, classes,rotation=0,fontdict={'family': 'Nimbus Roman','size': 25})

    fmt = '.3f' if normalize else 'd'
    for i, j in itertools.product(range(cm.shape[0]), range(cm.shape[1])):
        # 根据单元格的位置确定文本颜色
        text_color = 'white' if i == j else 'black'  # 对角线上的数字设为白色，其他设为黑色
        plt.text(j, i, format(cm[i, j], fmt),
                 horizontalalignment="center",
                 color=text_color,fontdict={'family': 'Nimbus Roman','size': 18})

    plt.ylabel('True label',fontdict={'family': 'Nimbus Roman','size': 40})
    plt.xlabel('Predicted label',fontdict={'family': 'Nimbus Roman','size': 40})
    plt.tight_layout()
    fig1.savefig(ad,dpi=1200,bbox_inches = 'tight')
   

def plot_heatmap(data, labels):
    """
    绘制分类结果的热力图

    参数:
    - data: 混淆矩阵或其他表示分类结果的数据
    - labels: 类别标签
    """
    # 创建一个热力图
    fig1 = plt.figure(figsize=(36, 18))
    tick_marks = np.arange(len(classes))
    plt.xticks(tick_marks, classes, rotation=0,fontdict={'family': 'Nimbus Roman','size': 20})
    plt.yticks(tick_marks, classes,rotation=0,fontdict={'family': 'Nimbus Roman','size': 20})
    heatmap = sns.heatmap(data, annot=True, cmap='YlGnBu', fmt='d',xticklabels=labels, yticklabels=labels,annot_kws = {"size":16})
    # YlGnBu  黄绿色到蓝色
    # cividis
    # coolwarm
    # viridis
    plt.ylabel('True label',fontdict={'family': 'Nimbus Roman','size': 30})
    plt.xlabel('Predicted label',fontdict={'family': 'Nimbus Roman','size': 30})
    # 获取 colorbar 对象
    cbar = heatmap.collections[0].colorbar
    # 设置 colorbar 标签的字体大小为 15
    cbar.ax.tick_params(labelsize=20)
    plt.show()
    fig1.savefig("./SAVEDATA/Confusionheatmap.png",dpi=800,bbox_inches = 'tight')
 
   
# 定义类别名称
# classes = ['0000','0001','0002','3','4','5','6','7','8','9','10','11','12','13','14','15','16','17','18','19','20','21','22','23','24','25','26','27','28','29','30','31','32','33','34','35','36','37']
classes = ['IFLD(a)','IRLD(b)','IFCD(c)','IRCD(d)',
           'ICBDFB(e)','INBDFB(f)','ICTDFB(g)','INTDFB(h)',
           'IFDFA(i)','IFDFB(j)','IRDFA(k)','IRTBY(l)',
           'IFSFB(m)','IRSFB(n)','IEFA(o)','IFECH(p)',
           'IRECH(q)','IFFH(r)','IRFH(s)',
           'OFLD(a)','ORLD(b)','OFCD(c)','ORCD(d)',
           'OCBDFB(e)','ONBDFB(f)','OCTDFB(g)','ONTDFB(h)',
           'OFDFA(i)','OFDFB(j)','ORDFA(k)','ORTBY(l)',
           'OFSFB(m)','ORSFB(n)','OEFA(o)','OFECH(p)',
           'ORECH(q)','OFFH(r)','ORFH(s)']
# 调用绘制函数
plot_confusion_matrix(CM[0:19,0:19], classes=classes[0:19],ad = "./SAVEDATA/ConfusionMatrix11.png",normalize=True,title='Confusion matrix, without normalization')
plot_confusion_matrix(CM[19:38,19:38], classes=classes[19:38],ad = "./SAVEDATA/ConfusionMatrix22.png",normalize=True,title='Confusion matrix, without normalization')



plot_heatmap(CM, labels=classes)


print('validate_accuracy_all ----->{:.10f} validate_F1_all----->{:.10f}'.format(validate_accuracy_mean, validate_F1_mean))
print('validate_precision_all ----->{:.10f} validate_recall_all----->{:.10f}'.format(validate_precision_mean, validate_recall_mean))
print('validate_F1_all----->{:.10f}'.format(validate_F2_all_mean))

# 导出
np.save('./SAVEDATA/true_lab_all.csv',true_lab_all) 
np.save('./SAVEDATA/pre_lab_all.csv',pre_lab_all) 
np.save('./SAVEDATA/probability_all.csv',probability_all) 

