#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Mar  6 10:43:24 2023

@author: sunqinbo
"""

## 导入本节所需的模块
import numpy as np
import matplotlib.pyplot as plt
import torch
from torch import nn
import torch.utils.data as Data
from sklearn.metrics import accuracy_score
from NetModel.BiGRUnet import BiGRUnet_SA

torch.cuda.empty_cache()
device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")

Train_Data = np.load('./Dataset/trainset/Train_DATA.csv.npy')
Train_Label = np.load('./Dataset/trainset/Train_DATA_labels.csv.npy')
Test_Data = np.load('./Dataset/trainset/Test_DATA.csv.npy')
Test_Label = np.load('./Dataset/trainset/Test_DATA_labels.csv.npy')

x_train_t = torch.from_numpy(Train_Data.astype(np.float32))
y_train_t = torch.from_numpy(Train_Label.astype(np.int64))

x_test_t = torch.from_numpy(Test_Data.astype(np.float32))
y_test_t = torch.from_numpy(Test_Label.astype(np.int64))


# 定义一个数据加载器
train_data = Data.TensorDataset(x_train_t,y_train_t)
train_loader = Data.DataLoader(
        dataset= train_data, 
        batch_size=4096, 
        # 随机排序
        shuffle=True,
        # 多个线程并行计算
        num_workers= 12
    )
test_data = Data.TensorDataset(x_test_t,y_test_t)
## 定义一个数据加载器
test_loader = Data.DataLoader(
        dataset= test_data, 
        batch_size=4096, 
        # 随机排序
        shuffle=True,
        # 多个线程并行计算
        num_workers= 12,
        pin_memory=True,
    )
for step_test, (b_x_test ,b_y_test) in enumerate(test_loader):
    if step_test == 0:
        break


## 模型调用
input_dim = 4       # 每行数据
seq_len = 10
hidden_dim = 80    # RNN神经元个数
layer_dim = 6       # RNN的层数
output_dim = 38     # 隐藏层输出的维度

MyBiGRUnet = BiGRUnet_SA(input_dim, hidden_dim, layer_dim, output_dim, seq_len ,input_dim, 1).to(device)


## 可视化循环神经网络'
'''
h1_graph = hl.build_graph(MyRNNimc, torch.zeros([1, 28, 28]))
h1_graph.theme = hl.graph.THEMES["blue"].copy()
h1_graph
'''

optimizer = torch.optim.Adam(MyBiGRUnet.parameters(), lr = 0.0005)
criterion = nn.CrossEntropyLoss().to(device)   # 损失函数

train_loss_all = []
train_acc_all = []
test_loss_all = []
test_acc_all = []

num_epochs = 160
print_step = 3710

for epoch in range(num_epochs):
    torch.cuda.empty_cache()
    print('Epoch{}/{}:   '.format(epoch, num_epochs - 1))
    MyBiGRUnet.train()   #转换为训练模式
    corrects = 0
    train_num = 0
    
    # 计算一个batch
    for step, (b_x, b_y) in enumerate(train_loader):
        ## input [batch, time_step, input_dim]
        torch.cuda.empty_cache()
        # 修改形状
        xdata = b_x.view(-1,seq_len,4)   
        # 前向计算
        output = MyBiGRUnet(xdata.cuda())
        # 确定标签
        pre_lab = torch.argmax(output, 1)
        # 计算损失函数
        train_loss =criterion(output, b_y.cuda())
        # 梯度清零
        optimizer.zero_grad()
        # 反向计算
        train_loss.backward()
        # 更新参数
        optimizer.step()
        # 计算一个batch的正确率
        pre_lab = pre_lab.cpu()
        train_accuracy = accuracy_score(b_y, pre_lab)
       
        niter = epoch * len(train_loader) + step + 1
        if niter % print_step == 0:   
            #(b_x_test ,b_y_test)
            b_x_test = b_x_test.to(device)
            output = MyBiGRUnet(b_x_test)  # 前向计算
            test_loss =criterion(output, b_y_test.cuda())
            pre_lab = torch.argmax(output, 1)  # 1代表行
            pre_lab = pre_lab.cpu()
            test_accuracy = accuracy_score(b_y_test, pre_lab)
            
            train_loss_all.append(train_loss.cpu().detach().numpy())
            train_acc_all.append(train_accuracy)
            test_loss_all.append(test_loss.cpu().detach().numpy())
            test_acc_all.append(test_accuracy)
            print('<------------------------------------------------------------------------------------')
            print('{}/{},epoch = {}: Train Loss ----->{:.10f} Train Acc----->{:.10f}'.format(step, len(train_loader), epoch,train_loss_all[-1], train_acc_all[-1]))
            print('{}/{},epoch = {}: Test Loss----->{:.10f} Test Acc----->{:.10f}'.format(step, len(train_loader),epoch,test_loss_all[-1], test_acc_all[-1]))
            print('------------------------------------------------------------------------------------>')
            print('\n')
            #转换为训练模式
            MyBiGRUnet.train()   
    torch.save(MyBiGRUnet, './SAVEMODEL/modelsave.pt')
            
                
#可视化训练过程
#绘制LOSS曲线
fig, ax1 = plt.subplots(figsize=(12,9))
ax1.set_ylabel('Loss', color = 'darkred',fontdict={'size': 20})
ax1.set_xlabel('Epochs', fontdict={'size': 20})
ax1.plot(train_loss_all, linestyle = "-" , lw = 3, color='darkred', label='Train_Loss curve for BiGRU')
ax1.plot(test_loss_all, linestyle = "-" , marker = '.',lw = 1, color='orangered', label='Test_Loss curve for BiGRU')
ax1.plot(train_loss_all, linestyle = "-" , lw = 2, color='darkred')
ax1.tick_params(axis='y', labelcolor='darkred')
ax1.set_xlim([-1, 216])
#ax1.set_ylim([0.0, 0.7])
plt.legend(prop={'size': 14},loc='upper left')
ax1.spines['bottom'].set_linewidth(2);###设置底部坐标轴的粗细
ax1.spines['left'].set_linewidth(2);###设置底部坐标轴的粗细
ax1.spines['right'].set_linewidth(2);###设置底部坐标轴的粗细
ax1.spines['top'].set_linewidth(2);###设置底部坐标轴的粗细
#绘制ACCURACY曲线
ax2 = ax1.twinx() 
ax2.set_ylabel('Accuracy', color = 'blue',fontdict={'size': 20})
ax2.set_xlabel('Epochs', fontdict={'size': 20})
ax2.plot(train_acc_all, linestyle = "-" , lw = 3, color='blue', label='Train_Accuracy curve for BiGRU')
ax2.plot(test_acc_all, linestyle = "-" , marker = '.',lw = 1, color='royalblue', label='Test_Accuracy curve for BiGRU')
ax2.plot(train_acc_all, linestyle = "-" , lw = 2, color='blue')
ax2.tick_params(axis='y', labelcolor='blue')
#ax2.set_xlim([-1, 500])
ax2.set_ylim([0.25, 1.09])
plt.legend(prop={'size': 14},loc='upper right')
plt.grid()
plt.savefig("./SAVEDATA/BiGRU.png",dpi=1200,bbox_inches = 'tight')

# 导出
np.save('./SAVEDATA/train_loss_all.csv',train_loss_all) 
np.save('./SAVEDATA/train_acc_all.csv',train_acc_all) 
np.save('./SAVEDATA/test_loss_all.csv',test_loss_all) 
np.save('./SAVEDATA/test_acc_all.csv',test_acc_all) 

# 保存模型
torch.save(MyBiGRUnet, './SAVEMODEL/modelsave.pt')




