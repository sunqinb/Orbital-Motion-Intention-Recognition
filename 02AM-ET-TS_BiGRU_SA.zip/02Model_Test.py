#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Apr 18 11:56:52 2023

@author: sunqinbo
"""
## 导入本节所需的模块
import numpy as np
import matplotlib.pyplot as plt
import torch
import torch.utils.data as Data
from sklearn.metrics import accuracy_score     # 准确率
from sklearn.metrics import precision_score    # 精确率
from sklearn.metrics import recall_score       # 召回率
from sklearn.metrics import f1_score           # F1分数
from sklearn.metrics import fbeta_score
from sklearn.metrics import confusion_matrix   # 混淆矩阵
from sklearn.metrics import classification_report# 分类报告
from sklearn.metrics import precision_recall_curve
from sklearn.metrics import average_precision_score
import itertools
import seaborn as sns
from matplotlib import rcParams
# 设置全局字体为 "Nimbus Roman"
rcParams['font.family'] = 'serif'
rcParams['font.serif'] = 'Nimbus Roman'

torch.cuda.empty_cache()
device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
Validate_Data = np.load('./Dataset/validation set/Test_DATA.csv.npy')
Validate_Label = np.load('./Dataset/validation set/Test_DATA_labels.csv.npy')

# 读取模型
MyBiGRUnet = torch.load('./SAVEMODEL/bigru120.pt')

x_validate_t = torch.from_numpy(Validate_Data.astype(np.float32))
y_validate_t = torch.from_numpy(Validate_Label.astype(np.int64))

# 定义一个数据加载器
validate_data = Data.TensorDataset(x_validate_t,y_validate_t)
validate_loader = Data.DataLoader(
        dataset= validate_data, 
        batch_size=3040, 
        # 随机排序
        shuffle=True,
        # 多个线程并行计算
        num_workers= 5
    )

validate_acc_all = []
validate_precision_all = []
validate_recall_all = []
validate_F1_all = []
validate_F2_all = []

torch.cuda.empty_cache()
true_lab_all = np.array([])
pre_lab_all  = np.array([])
probability_all = np.array([])
for step, (b_x, b_y) in enumerate(validate_loader):
    b_x = b_x.to(device)
    output = MyBiGRUnet(b_x)  # 前向计算
    probability = torch.softmax(output,1).cpu()
    pre_lab = torch.argmax(output, 1)  # 1代表行
    pre_lab = pre_lab.cpu()
    
    # 准确率 validate_accuracy
    validate_accuracy = accuracy_score(b_y, pre_lab)
    # 精确率 precision
    validate_precision = precision_score(b_y, pre_lab,average='macro')
    # 召回率 recall
    validate_recall = recall_score(b_y, pre_lab,average='macro')
    # F1 分数
    validate_F1 = f1_score(b_y, pre_lab,average='macro')
    validate_F2 = fbeta_score(b_y, pre_lab,beta=2,average='macro')
    # 数据拼接
    validate_acc_all.append(validate_accuracy)
    validate_precision_all.append(validate_precision)
    validate_recall_all.append(validate_recall)
    validate_F1_all.append(validate_F1)
    validate_F2_all.append(validate_F2)
    
    # 记录结果 标签
    true_lab_numpy = b_y.numpy()  # 真实标签
    true_lab_all = np.append(true_lab_all,true_lab_numpy)
    pre_lab_numpy = pre_lab.numpy()  # 预测标签
    pre_lab_all = np.append(pre_lab_all,pre_lab_numpy)
    probability_numpy = probability.detach().numpy()
    if step ==0:
        probability_all = probability_numpy
    else:
        probability_all = np.vstack([probability_all,probability_numpy])
 
np.save('./SAVEDATA/validate_acc_all.csv',validate_acc_all) 
np.save('./SAVEDATA/validate_precision_all.csv',validate_precision_all) 
np.save('./SAVEDATA/validate_recall_all.csv',validate_recall_all)    
np.save('./SAVEDATA/validate_F1_all.csv',validate_F1_all)    
np.save('./SAVEDATA/validate_F2_all.csv',validate_F2_all)   
 


# 准确率 validate_accuracy
validate_accuracy_mean = accuracy_score(true_lab_all, pre_lab_all)
# 精确率 precision
validate_precision_mean = precision_score(true_lab_all, pre_lab_all,average='macro')
# 召回率 recall
validate_recall_mean = recall_score(true_lab_all, pre_lab_all,average='macro')
# F1 分数
validate_F1_mean = f1_score(true_lab_all, pre_lab_all,average='macro')
# F1 分数
validate_F2_all_mean = fbeta_score(true_lab_all, pre_lab_all,beta=2,average='macro')

# 混淆矩阵
CM = confusion_matrix(true_lab_all,pre_lab_all)
M2 = CM
#分类报告输出
CR = classification_report(true_lab_all, pre_lab_all)
M1 = CR


print('validate_accuracy_all ----->{:.10f} validate_F1_all----->{:.10f}'.format(validate_accuracy_mean, validate_F1_mean))
print('validate_precision_all ----->{:.10f} validate_recall_all----->{:.10f}'.format(validate_precision_mean, validate_recall_mean))
print('validate_F1_all----->{:.10f}'.format(validate_F2_all_mean))

# 导出
np.save('./SAVEDATA/true_lab_all.csv',true_lab_all) 
np.save('./SAVEDATA/pre_lab_all.csv',pre_lab_all) 
np.save('./SAVEDATA/probability_all.csv',probability_all) 
