#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu May  4 10:24:30 2023

@author: change
"""
import torch
import numpy as np
from torch import nn

class BiGRUnet(nn.Module):
    def __init__(self, input_dim, hidden_dim, layer_dim, output_dim):
        '''
        Parameters
        ----------
        imput_dim : 输入数据的维度，图像即为每行的像素点.
        hidden_dim : RNN个神经元
        layder_dim : RNN 的层数
        output_dim : 隐藏层输出的维度
        '''
        super (BiGRUnet,self).__init__()
        self.hidden_dim = hidden_dim
        self.layer_dim = layer_dim
        #层数
        self.gru = nn.GRU(input_dim, hidden_dim, layer_dim, batch_first=True, bidirectional=True)
        '''
        batch_first=True,RNN输入变量的第一个维度为批数据（batch）  此处与编成习惯相关
        '''        
        # 连接全连接层
        self.fc1 = nn.Linear(2 * hidden_dim, output_dim)
        
    def forward(self, x):
    ## x:[batch, time_step, input_dim]
        r_out, h_n = self.gru(x, None)
        out = self.fc1(r_out[:, -1, :])
    
        return out

class BiGRUnet_SA(nn.Module):
    def __init__(self, input_dim, hidden_dim, layer_dim, output_dim, seq_len, dim_k = None, dim_v = None):
        '''
        Parameters
        ----------
        imput_dim : 输入数据的维度.
        hidden_dim : GRU个神经元
        layder_dim : GRU的层数
        output_dim : 隐藏层输出的维度
        dim_k : K，Q矩阵的维度参数
        dim_v : V矩阵的维度参数，也是self attention模块的输出向量维度，假如输出需要5维向量，则设置为5
        '''
        super (BiGRUnet_SA,self).__init__()
        self.input_dim = input_dim
        
        """01 BiGRU层参数设置"""
        self.hidden_dim = hidden_dim
        self.layer_dim = layer_dim
        #层数
        self.gru = nn.GRU(input_dim, hidden_dim, layer_dim, batch_first=True, bidirectional=True)
        
        """02 Self Attention层参数设置"""
        # 如果 dim_k 与 dim_v 为 None,则取输入向量的维度
        if dim_k is None:
            dim_k = input_dim
        if dim_v is None:
            dim_v = input_dim
        
        # 用线性层来表示需要训练的矩阵，方便反向传播和参数更新
        self.W_q = nn.Linear(2 * hidden_dim, dim_k, bias=False)
        self.W_k = nn.Linear(2 * hidden_dim, dim_k, bias=False)
        self.W_v = nn.Linear(2 * hidden_dim, dim_v, bias=False)
        self._norm_fact = 1 / np.sqrt(dim_k)
        
        
        '''
        batch_first=True,RNN输入变量的第一个维度为批数据（batch）  此处与编成习惯相关
        '''        
        """03 全连接层参数设置"""
        self.fc1 = nn.Linear(seq_len, output_dim)
        
    def forward(self, x):
        """
        x: 一次用于训练的batch，size为[batch_size, seq_size , vector_dim]
        """
        '''
        NO01 BiGRU 计算
        '''
        r_out, h_n = self.gru(x, None)
        
        '''
        NO02 self attention 计算
        '''
        # 通过W_q, W_k, W_v矩阵计算出，Q,K,V
        # Q,K矩阵的size为 (batch_size, seq_size, dim_k)      
        # V 矩阵的size为 (batch_size, seq_size, dim_v) 
        # r_out size为 (batch_size, seq_size, 2 * hidden_dim) 
        Q = self.W_q(r_out)
        K = self.W_k(r_out)
        V = self.W_v(r_out)
        
        # 对K进行转置
        K_T = K.permute(0, 2, 1)
        # permute用于变换矩阵的size中对应元素的位置
        # 即，将K的size由(batch_size, seq_size, dim_k)，变为(batch_size, dim_k, seq_size)
        
        # 计算评分矩阵  进行行softmax
        A = nn.Softmax(dim=-1)(torch.bmm(Q, K_T)) * self._norm_fact
        # 最后再乘以V得到 output_of_self_attention， size为[batch_size, seq_size , dim_v] 
        output_of_self_attention = torch.bmm(A, V)
        tes=output_of_self_attention[:,:,-1]
        '''
        NO03 全连接层计算
        '''
        out = self.fc1(tes)
    
        return out
